"""Run MQI_HGWO and the GWO variants and write raw metrics to results/*.csv.

Metrics: fitness, coverage, connectivity, energy per round, residual energy (J),
alive nodes per round, end-to-end delay (ms), convergence curves.

Usage: python scripts/run_experiments.py [--config configs/params.json] [--out results] [--quick]
"""
import argparse
import csv
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from gwo_variants import ALGORITHMS  # noqa: E402
from network import fitness, make_vehicles  # noqa: E402


def evaluate(heads, vehicles, cfg):
    """Coverage, connectivity, delay and lifetime metrics for a head layout."""
    k, r = cfg["num_heads"], cfg["comm_range"]
    d = np.linalg.norm(vehicles[:, None, :] - heads[None, :, :], axis=2)
    nearest, owner = d.min(axis=1), d.argmin(axis=1)
    coverage = float(np.mean(nearest <= r))

    hh = np.linalg.norm(heads[:, None] - heads[None, :], axis=2) <= r
    sink = int(np.argmin(np.linalg.norm(heads - cfg["area"] / 2, axis=1)))
    hops = np.full(k, np.inf)
    hops[sink] = 0
    frontier = [sink]
    while frontier:
        nxt = []
        for u in frontier:
            for v in np.where(hh[u])[0]:
                if hops[v] == np.inf:
                    hops[v] = hops[u] + 1
                    nxt.append(int(v))
        frontier = nxt
    connectivity = float(np.mean(np.isfinite(hops)))

    members = np.bincount(owner, minlength=k)
    hop_per_vehicle = hops[owner]
    reach = np.isfinite(hop_per_vehicle) & (nearest <= r)
    # delay: 2 ms/hop (member->head counts as one hop) + 0.05 ms queueing per member
    delay = 2.0 * (1 + hop_per_vehicle[reach]) + 0.05 * members[owner[reach]]
    e2e = float(delay.mean()) if reach.any() else float("nan")
    return coverage, connectivity, e2e, nearest, owner, members


def lifetime(nearest, owner, members, cfg):
    """Round-by-round residual energy and alive nodes."""
    n = len(nearest)
    E = np.full(n, cfg["initial_energy_j"])
    bits, ee, ea = cfg["packet_bits"], cfg["e_elec"], cfg["e_amp"]
    head_extra = bits * ee * members[owner]  # head receives from all members
    cost = bits * (ee + ea * nearest ** 2) + 0.02 * head_extra / np.maximum(members[owner], 1)
    residual, alive = [], []
    for _ in range(cfg["rounds"]):
        E = np.maximum(E - cost * cfg["packets_per_round"], 0)
        residual.append(float(E.sum()))
        alive.append(int((E > 0).sum()))
    return residual, alive


def write_csv(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/params.json")
    ap.add_argument("--out", default="results")
    ap.add_argument("--quick", action="store_true", help="small run for smoke testing")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    if a.quick:
        cfg.update(population=10, iterations=15, vehicle_counts=[50, 100], rounds=100)
    os.makedirs(a.out, exist_ok=True)

    k = cfg["num_heads"]
    dim, lb, ub = 2 * k, 0.0, cfg["area"]
    summary, conv_rows, energy_rows, alive_rows = [], [], [], []
    ref_n = cfg["vehicle_counts"][len(cfg["vehicle_counts"]) // 2]

    for n in cfg["vehicle_counts"]:
        for name, algo in ALGORITHMS.items():
            # same seed per (n, algorithm) -> reproducible, and same vehicle layout for all algorithms
            veh = make_vehicles(n, cfg["area"], np.random.default_rng(cfg["seed"] + n))
            rng = np.random.default_rng(cfg["seed"] + n * 31 + sum(map(ord, name)))
            best, f, curve = algo(lambda x: fitness(x, veh, cfg), dim, lb, ub,
                                  cfg["population"], cfg["iterations"], rng)
            cov, con, e2e, nearest, owner, members = evaluate(best.reshape(k, 2), veh, cfg)
            residual, alive = lifetime(nearest, owner, members, cfg)
            summary.append([n, name, f, cov, con, e2e, residual[-1], alive[-1]])
            if n == ref_n:
                conv_rows += [[name, i, v] for i, v in enumerate(curve)]
                alive_rows += [[name, i + 1, v] for i, v in enumerate(alive)]
            energy_rows.append([n, name, residual[-1], residual[-1] / (n * cfg["initial_energy_j"])])
            print(f"n={n:4d} {name:12s} F={f:.4f} cov={cov:.3f} conn={con:.2f} "
                  f"e2e={e2e:.2f}ms residual={residual[-1]:.1f}J")

    write_csv(f"{a.out}/summary.csv",
              ["vehicles", "algorithm", "fitness", "coverage", "connectivity",
               "e2e_delay_ms", "residual_energy_J", "alive_nodes_end"], summary)
    write_csv(f"{a.out}/convergence.csv", ["algorithm", "iteration", "best_fitness"], conv_rows)
    write_csv(f"{a.out}/alive_nodes.csv", ["algorithm", "round", "alive_nodes"], alive_rows)
    write_csv(f"{a.out}/energy_efficiency.csv",
              ["vehicles", "algorithm", "residual_energy_J", "residual_fraction"], energy_rows)
    print(f"results written to {a.out}/")


if __name__ == "__main__":
    main()
