"""Generate synthetic vehicle mobility traces (Manhattan-style grid, CSV).

Output columns: step, vehicle_id, x, y, speed
Usage: python scripts/generate_traces.py [--config configs/params.json] [--out traces/mobility.csv]
"""
import argparse
import csv
import json
import os

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/params.json")
    ap.add_argument("--out", default="traces/mobility.csv")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    rng = np.random.default_rng(cfg["seed"])
    n, steps, area = cfg["trace_vehicles"], cfg["trace_steps"], cfg["area"]
    block = 100.0  # road spacing (m)

    pos = rng.uniform(0, area, (n, 2))
    # each vehicle drives along one axis of a grid road
    axis = rng.integers(0, 2, n)
    pos[np.arange(n), 1 - axis] = np.round(pos[np.arange(n), 1 - axis] / block) * block
    speed = rng.uniform(8, 20, n)  # m/s
    direction = rng.choice([-1, 1], n)

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["step", "vehicle_id", "x", "y", "speed"])
        for t in range(steps):
            for i in range(n):
                w.writerow([t, i, round(pos[i, 0], 2), round(pos[i, 1], 2), round(speed[i], 2)])
            for i in range(n):
                pos[i, axis[i]] += direction[i] * speed[i]
                if pos[i, axis[i]] < 0 or pos[i, axis[i]] > area:
                    direction[i] *= -1
                    pos[i, axis[i]] = np.clip(pos[i, axis[i]], 0, area)
    print(f"wrote {a.out}: {n} vehicles x {steps} steps")


if __name__ == "__main__":
    main()
