"""GWO baseline, six GWO variants, and MQI_HGWO (reference implementation).

All optimisers share the signature  opt(fobj, dim, lb, ub, pop, iters, rng)
and return (best_position, best_fitness, convergence_curve).

NOTE: the variants below are common, simplified GWO modifications used as
baselines. Replace/extend them with the exact operators from your paper if
they differ.
"""
import numpy as np


def _init(pop, dim, lb, ub, rng):
    return rng.uniform(lb, ub, (pop, dim))


def _leaders(X, fit):
    idx = np.argsort(fit)[:3]
    return X[idx[0]].copy(), X[idx[1]].copy(), X[idx[2]].copy(), fit[idx[0]]


def _gwo_step(X, a, alpha, beta, delta, rng):
    new = np.zeros_like(X)
    for lead in (alpha, beta, delta):
        A = 2 * a * rng.random(X.shape) - a
        C = 2 * rng.random(X.shape)
        new += lead - A * np.abs(C * lead - X)
    return new / 3.0


def _run(fobj, dim, lb, ub, pop, iters, rng, a_fn=None, post=None, init=None):
    X = init(pop, dim, lb, ub, rng) if init else _init(pop, dim, lb, ub, rng)
    fit = np.array([fobj(x) for x in X])
    best, curve = (None, np.inf), []
    for t in range(iters):
        alpha, beta, delta, f_alpha = _leaders(X, fit)
        if f_alpha < best[1]:
            best = (alpha.copy(), f_alpha)
        a = a_fn(t, iters) if a_fn else 2 * (1 - t / iters)
        X = np.clip(_gwo_step(X, a, alpha, beta, delta, rng), lb, ub)
        if post:
            X = np.clip(post(X, alpha, t, iters, rng, fobj, lb, ub), lb, ub)
        fit = np.array([fobj(x) for x in X])
        curve.append(best[1])
    alpha, _, _, f_alpha = _leaders(X, fit)
    if f_alpha < best[1]:
        best = (alpha.copy(), f_alpha)
    curve.append(best[1])
    return best[0], best[1], np.array(curve)


# ---- baselines -------------------------------------------------------------
def gwo(fobj, dim, lb, ub, pop, iters, rng):
    return _run(fobj, dim, lb, ub, pop, iters, rng)


def i_gwo(fobj, dim, lb, ub, pop, iters, rng):  # nonlinear a decay
    return _run(fobj, dim, lb, ub, pop, iters, rng,
                a_fn=lambda t, T: 2 * (1 - (t / T) ** 2))


def opposition_gwo(fobj, dim, lb, ub, pop, iters, rng):  # opposition-based init
    def init(p, d, l, u, r):
        X = _init(p, d, l, u, r)
        Xo = l + u - X
        both = np.vstack([X, Xo])
        f = np.array([fobj(x) for x in both])
        return both[np.argsort(f)[:p]]
    return _run(fobj, dim, lb, ub, pop, iters, rng, init=init)


def levy_gwo(fobj, dim, lb, ub, pop, iters, rng):  # Levy-flight perturbation
    def post(X, alpha, t, T, r, f, l, u):
        step = r.standard_normal(X.shape) / np.abs(r.standard_normal(X.shape)) ** (1 / 1.5)
        return X + 0.01 * step * (X - alpha) * (1 - t / T)
    return _run(fobj, dim, lb, ub, pop, iters, rng, post=post)


def chaotic_gwo(fobj, dim, lb, ub, pop, iters, rng):  # logistic-map init
    def init(p, d, l, u, r):
        z = r.random((p, d)) * 0.9 + 0.05
        for _ in range(10):
            z = 4 * z * (1 - z)
        return l + z * (u - l)
    return _run(fobj, dim, lb, ub, pop, iters, rng, init=init)


def de_gwo(fobj, dim, lb, ub, pop, iters, rng):  # differential-evolution mutation
    def post(X, alpha, t, T, r, f, l, u):
        n = len(X)
        out = X.copy()
        for i in range(n):
            a, b, c = X[r.choice(n, 3, replace=False)]
            trial = a + 0.5 * (b - c)
            mask = r.random(dim) < 0.5
            cand = np.clip(np.where(mask, trial, X[i]), l, u)
            if f(cand) < f(X[i]):
                out[i] = cand
        return out
    return _run(fobj, dim, lb, ub, pop, iters, rng, post=post)


def pso_gwo(fobj, dim, lb, ub, pop, iters, rng):  # PSO-style pull toward alpha
    def post(X, alpha, t, T, r, f, l, u):
        w = 0.9 - 0.5 * t / T
        return X + w * r.random(X.shape) * (alpha - X) * 0.5
    return _run(fobj, dim, lb, ub, pop, iters, rng, post=post)


# ---- proposed --------------------------------------------------------------
def mqi_hgwo(fobj, dim, lb, ub, pop, iters, rng):
    """Quantum-inspired GWO with hybrid local search.

    Each agent carries a qubit angle theta; its observed position is
    collapsed from the quantum state. A rotation-gate update steers theta
    toward the alpha wolf (exploration), quantum mutation (NOT-gate) keeps
    diversity, and a GWO-style local search refines the leaders (exploitation).
    """
    theta = rng.uniform(0, np.pi / 2, (pop, dim))
    span = ub - lb

    def observe(th):
        prob1 = np.sin(th) ** 2
        collapse = rng.random(th.shape) < prob1
        return lb + span * np.where(collapse, prob1, 1 - prob1) * rng.uniform(0.9, 1.0, th.shape)

    X = observe(theta)
    fit = np.array([fobj(x) for x in X])
    best, curve = (None, np.inf), []
    for t in range(iters):
        alpha, beta, delta, f_alpha = _leaders(X, fit)
        if f_alpha < best[1]:
            best = (alpha.copy(), f_alpha)
        a = 2 * (1 - t / iters)
        # GWO move (exploitation)
        Xg = np.clip(_gwo_step(X, a, alpha, beta, delta, rng), lb, ub)
        # rotation gate toward alpha (quantum exploration)
        target = (alpha - lb) / span
        cur = (X - lb) / span
        dth = (0.05 * np.pi) * (1 - t / iters) * np.sign(target - cur)
        theta = np.clip(theta + dth, 0, np.pi / 2)
        # quantum mutation: swap amplitudes for a few qubits
        mut = rng.random(theta.shape) < 0.02
        theta = np.where(mut, np.pi / 2 - theta, theta)
        Xq = observe(theta)
        # keep the better of GWO move / quantum observation per agent
        fg = np.array([fobj(x) for x in Xg])
        fq = np.array([fobj(x) for x in Xq])
        take_q = fq < fg
        X = np.where(take_q[:, None], Xq, Xg)
        fit = np.where(take_q, fq, fg)
        # local search around alpha (hybrid operator)
        for _ in range(3):
            cand = np.clip(alpha + rng.normal(0, 0.02 * span * (1 - t / iters) + 1e-9, dim), lb, ub)
            fc = fobj(cand)
            if fc < best[1]:
                best = (cand.copy(), fc)
        curve.append(best[1])
    alpha, _, _, f_alpha = _leaders(X, fit)
    if f_alpha < best[1]:
        best = (alpha.copy(), f_alpha)
    curve.append(best[1])
    return best[0], best[1], np.array(curve)


ALGORITHMS = {
    "MQI_HGWO": mqi_hgwo,
    "GWO": gwo,
    "I-GWO": i_gwo,
    "OBL-GWO": opposition_gwo,
    "Levy-GWO": levy_gwo,
    "Chaotic-GWO": chaotic_gwo,
    "DE-GWO": de_gwo,
    "PSO-GWO": pso_gwo,
}
