"""VANET fitness model: coverage, connectivity and energy of a cluster-head set.

A candidate solution is a vector of 2*K values in [0, area]: the (x, y)
positions of K cluster heads. Lower fitness is better.
"""
import numpy as np


def make_vehicles(n, area, rng):
    return rng.uniform(0, area, (n, 2))


def fitness(sol, vehicles, cfg):
    k = cfg["num_heads"]
    heads = sol.reshape(k, 2)
    r = cfg["comm_range"]
    d = np.linalg.norm(vehicles[:, None, :] - heads[None, :, :], axis=2)  # n x k
    nearest = d.min(axis=1)

    coverage = np.mean(nearest <= r)  # fraction of vehicles within range of a head
    # connectivity: fraction of heads linked (directly or by multi-hop) to the largest component
    hh = np.linalg.norm(heads[:, None, :] - heads[None, :, :], axis=2) <= r
    seen, stack = {0}, [0]
    while stack:
        u = stack.pop()
        for v in np.where(hh[u])[0]:
            if v not in seen:
                seen.add(int(v))
                stack.append(int(v))
    connectivity = len(seen) / k
    # energy proxy: free-space transmission cost of member -> head links (normalised)
    energy = np.mean((nearest / cfg["area"]) ** 2)

    w = cfg["weights"]
    return (w["coverage"] * (1 - coverage)
            + w["connectivity"] * (1 - connectivity)
            + w["energy"] * energy)
