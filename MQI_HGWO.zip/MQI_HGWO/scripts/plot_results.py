"""Plot figures from results/*.csv into results/figures/.

Usage: python scripts/plot_results.py [--results results]
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402


def line_plot(df, x, y, xlabel, ylabel, title, path):
    fig, ax = plt.subplots(figsize=(6, 4))
    for name, g in df.groupby("algorithm", sort=False):
        ax.plot(g[x], g[y], marker="o" if df[x].nunique() < 15 else None,
                lw=2.4 if name == "MQI_HGWO" else 1.2, label=name,
                zorder=3 if name == "MQI_HGWO" else 2)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    fig_dir = os.path.join(a.results, "figures")
    os.makedirs(fig_dir, exist_ok=True)
    s = pd.read_csv(f"{a.results}/summary.csv")

    line_plot(s, "vehicles", "residual_energy_J", "Number of vehicles", "Residual energy (J)",
              "Residual energy versus number of vehicles", f"{fig_dir}/residual_energy.png")
    line_plot(s, "vehicles", "e2e_delay_ms", "Number of vehicles", "End-to-end delay (ms)",
              "End-to-end delay versus number of vehicles", f"{fig_dir}/e2e_delay.png")
    line_plot(s, "vehicles", "coverage", "Number of vehicles", "Coverage",
              "Coverage versus number of vehicles", f"{fig_dir}/coverage.png")
    line_plot(s, "vehicles", "connectivity", "Number of vehicles", "Connectivity",
              "Connectivity versus number of vehicles", f"{fig_dir}/connectivity.png")
    e = pd.read_csv(f"{a.results}/energy_efficiency.csv")
    line_plot(e, "vehicles", "residual_fraction", "Number of vehicles", "Energy efficiency (residual fraction)",
              "Energy efficiency versus number of vehicles", f"{fig_dir}/energy_efficiency.png")
    c = pd.read_csv(f"{a.results}/convergence.csv")
    line_plot(c, "iteration", "best_fitness", "Iteration", "Best fitness",
              "Convergence curves", f"{fig_dir}/convergence.png")
    al = pd.read_csv(f"{a.results}/alive_nodes.csv")
    line_plot(al, "round", "alive_nodes", "Round", "Alive nodes",
              "Alive nodes versus rounds", f"{fig_dir}/alive_nodes.png")
    print(f"figures written to {fig_dir}/")


if __name__ == "__main__":
    main()
