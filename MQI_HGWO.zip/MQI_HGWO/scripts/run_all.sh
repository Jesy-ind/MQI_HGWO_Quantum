#!/usr/bin/env bash
# Reproduce all traces, results and figures. Add --quick for a fast smoke test.
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/generate_traces.py --config configs/params.json --out traces/mobility.csv
python scripts/run_experiments.py --config configs/params.json --out results "$@"
python scripts/plot_results.py --results results
